main_menu = """
 __        _____  ____  ____    ____  _____    _    ____   ____ _   _      
 \ \      / / _ \|  _ \|  _ \  / ___|| ____|  / \  |  _ \ / ___| | | |     
  \ \ /\ / / | | | |_) | | | | \___ \|  _|   / _ \ | |_) | |   | |_| |     
   \ V  V /| |_| |  _ <| |_| |  ___) | |___ / ___ \|  _ <| |___|  _  |     
  __\_/\_/ _\___/|_| \_\____/  |____/|_____/_/___\_\_|_\_\\____|_| |_|_    
 |  _ \ \ / /_   _| | | |/ _ \| \ | | |_   _|  _ \|_ _\ \   / /_ _|  / \   
 | |_) \ V /  | | | |_| | | | |  \| |   | | | |_) || | \ \ / / | |  / _ \  
 |  __/ | |   | | |  _  | |_| | |\  |   | | |  _ < | |  \ V /  | | / ___ \ 
 |_|    |_|   |_| |_| |_|\___/|_| \_|   |_| |_| \_\___|  \_/  |___/_/   \_\
                                                                           

                            BY: JOSH BOTHELL
                            
    Press enter to continue"""
trivia_1 = "Number with a decimal: "
answer_1 = "float"

trivia_2 = "Sequence of characters: "
answer_2 = "string"

trivia_3 = "Only has true/false state: "
answer_3 = "boolean"

trivia_4 = "Named memory location holding a value: "
answer_4 = "variable"

trivia_5 = "Explanations written in the code, but ignored by python: "
answer_5 = "comments"

trivia_6 = "Series of related steps that make up a larger task: "
answer_6 = "function"

trivia_7 = "Variable defined in the 'def' statement of a function: "
answer_7 = "parameter"

trivia_8 = "Variable whose value does not change throughout a program: "
answer_8 = "constant"

trivia_9 = "Block of code that is repeated until a certain condition is met: "
answer_9 = "loop"

trivia_10 = "Whole number: "
answer_10 = "integer"

puzzle = "gelbairavafpcommentsuamzotniltnrtnatsnoccahrrbhtostmhxbbvepziestringfyotmbooleannetzpzlrehzrtaolfzag"

puzzle_pretty = """
  0123456789
0 gelbairava
1 fpcomments
2 uamzotnilt
3 nrtnatsnoc
4 cahrrbhtos
5 tmhxbbvepz
6 iestringfy
7 otmboolean
8 netzpzlreh
9 zrtaolfzag
"""
correct = "Correct!"
incorrect = "That was incorrect, Try again!"
fail = "You ran out of tries, move on to the next question"

length_1 = len(answer_1)
length_2 = len(answer_2)
length_3 = len(answer_3)
length_4 = len(answer_4)
length_5 = len(answer_5)
length_6 = len(answer_6)
length_7 = len(answer_7)
length_8 = len(answer_8)
length_9 = len(answer_9)
length_10 = len(answer_10)

enter_pos = "Enter the index position (with a comma after each number INCLUDING THE LAST NUMBER) of"
